﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/// <summary>
/// DM ME ON DISCORD FOR CHEAP C# GUIs!!! CHEAP, MODERN, CLEAN. I MAKE CUSTOM NOT SKIDDED!!!   
/// BlackHat#0060
/// </summary>
/// 


/// <summary>
/// DM ME ON DISCORD FOR CHEAP C# GUIs!!! CHEAP, MODERN, CLEAN. I MAKE CUSTOM NOT SKIDDED!!!   
/// BlackHat#0060
/// </summary>
/// 


/// <summary>
/// DM ME ON DISCORD FOR CHEAP C# GUIs!!! CHEAP, MODERN, CLEAN. I MAKE CUSTOM NOT SKIDDED!!!   
/// BlackHat#0060
/// </summary>
/// 
/// 
/// <summary>
/// DM ME ON DISCORD FOR CHEAP C# GUIs!!! CHEAP, MODERN, CLEAN. I MAKE CUSTOM NOT SKIDDED!!!   
/// BlackHat#0060
/// </summary>
/// 

namespace Zoom
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
            {
                WindowState = FormWindowState.Minimized;
            }
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            Zoom rr = new Zoom();
            rr.Show();
            
        }

        private void main_Load(object sender, EventArgs e)
        {

        }
    }
}

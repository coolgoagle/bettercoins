﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Zoom
{
    public partial class settings : Form
    {
        public settings()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            
        }

        private void guna2HtmlLabel6_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            
            
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://youtube.com/Nightbot");
            System.Diagnostics.Process.Start("http://cheat.gq");
        }

        private void guna2Button1_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://discord.gg/YwZ2pSpJ3N");
        }
    }
}

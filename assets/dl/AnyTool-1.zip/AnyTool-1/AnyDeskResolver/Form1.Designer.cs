﻿namespace AnyDeskResolver
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.flatTabControl1 = new Wagwan_clicker.FlatTabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.skeetGroupBox1 = new Wagwan_clicker.SkeetGroupBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.skeetButton1 = new Wagwan_clicker.SkeetButton();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.skeetGroupBox4 = new Wagwan_clicker.SkeetGroupBox();
            this.skeetButton12 = new Wagwan_clicker.SkeetButton();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.skeetGroupBox2 = new Wagwan_clicker.SkeetGroupBox();
            this.skeetButton2 = new Wagwan_clicker.SkeetButton();
            this.skeetGroupBox3 = new Wagwan_clicker.SkeetGroupBox();
            this.skeetTextBox1 = new Wagwan_clicker.SkeetTextBox();
            this.skeetToggle1 = new Wagwan_clicker.SkeetToggle();
            this.skeetBackground1 = new CucklordPRO.SkeetBackground();
            this.panel1.SuspendLayout();
            this.flatTabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.skeetGroupBox1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.skeetGroupBox4.SuspendLayout();
            this.skeetGroupBox2.SuspendLayout();
            this.skeetGroupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(10, 8);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(781, 46);
            this.panel1.TabIndex = 5;
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label7.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.label7.Location = new System.Drawing.Point(755, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(14, 14);
            this.label7.TabIndex = 4;
            this.label7.Text = "X";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label6.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.label6.Location = new System.Drawing.Point(738, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(14, 14);
            this.label6.TabIndex = 3;
            this.label6.Text = "_";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label2.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label2.Location = new System.Drawing.Point(416, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "settings";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label1.Location = new System.Drawing.Point(311, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Resolver";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // flatTabControl1
            // 
            this.flatTabControl1.ActiveColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(168)))), ((int)(((byte)(109)))));
            this.flatTabControl1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.flatTabControl1.Controls.Add(this.tabPage2);
            this.flatTabControl1.Controls.Add(this.tabPage1);
            this.flatTabControl1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.flatTabControl1.ItemSize = new System.Drawing.Size(120, 40);
            this.flatTabControl1.Location = new System.Drawing.Point(12, 12);
            this.flatTabControl1.Name = "flatTabControl1";
            this.flatTabControl1.SelectedIndex = 0;
            this.flatTabControl1.Size = new System.Drawing.Size(776, 426);
            this.flatTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.flatTabControl1.TabIndex = 4;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.tabPage2.Controls.Add(this.skeetGroupBox1);
            this.tabPage2.Controls.Add(this.skeetButton1);
            this.tabPage2.Location = new System.Drawing.Point(4, 44);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(768, 378);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            // 
            // skeetGroupBox1
            // 
            this.skeetGroupBox1.Controls.Add(this.richTextBox2);
            this.skeetGroupBox1.Font = new System.Drawing.Font("Verdana", 7F);
            this.skeetGroupBox1.Location = new System.Drawing.Point(15, 20);
            this.skeetGroupBox1.Name = "skeetGroupBox1";
            this.skeetGroupBox1.Size = new System.Drawing.Size(750, 291);
            this.skeetGroupBox1.TabIndex = 1;
            this.skeetGroupBox1.TabStop = false;
            this.skeetGroupBox1.Text = "History [IP, Country Code VPN]";
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.richTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox2.ForeColor = System.Drawing.Color.Gray;
            this.richTextBox2.Location = new System.Drawing.Point(6, 31);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.ReadOnly = true;
            this.richTextBox2.Size = new System.Drawing.Size(725, 233);
            this.richTextBox2.TabIndex = 1;
            this.richTextBox2.Text = "";
            // 
            // skeetButton1
            // 
            this.skeetButton1.ColorBottom = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(28)))), ((int)(((byte)(201)))));
            this.skeetButton1.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(28)))), ((int)(((byte)(201)))));
            this.skeetButton1.Font = new System.Drawing.Font("Verdana", 13F);
            this.skeetButton1.Location = new System.Drawing.Point(289, 326);
            this.skeetButton1.Name = "skeetButton1";
            this.skeetButton1.Size = new System.Drawing.Size(190, 32);
            this.skeetButton1.TabIndex = 0;
            this.skeetButton1.Text = "Resolve";
            this.skeetButton1.Click += new System.EventHandler(this.skeetButton1_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.tabPage1.Controls.Add(this.skeetGroupBox4);
            this.tabPage1.Controls.Add(this.skeetGroupBox2);
            this.tabPage1.Location = new System.Drawing.Point(4, 44);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(768, 378);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            // 
            // skeetGroupBox4
            // 
            this.skeetGroupBox4.Controls.Add(this.skeetButton12);
            this.skeetGroupBox4.Controls.Add(this.label13);
            this.skeetGroupBox4.Controls.Add(this.label15);
            this.skeetGroupBox4.Font = new System.Drawing.Font("Verdana", 7F);
            this.skeetGroupBox4.Location = new System.Drawing.Point(411, 118);
            this.skeetGroupBox4.Name = "skeetGroupBox4";
            this.skeetGroupBox4.Size = new System.Drawing.Size(224, 143);
            this.skeetGroupBox4.TabIndex = 3;
            this.skeetGroupBox4.TabStop = false;
            this.skeetGroupBox4.Text = "ID Changer";
            // 
            // skeetButton12
            // 
            this.skeetButton12.ColorBottom = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(28)))), ((int)(((byte)(201)))));
            this.skeetButton12.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(28)))), ((int)(((byte)(201)))));
            this.skeetButton12.Font = new System.Drawing.Font("Verdana", 7F);
            this.skeetButton12.Location = new System.Drawing.Point(133, 104);
            this.skeetButton12.Name = "skeetButton12";
            this.skeetButton12.Size = new System.Drawing.Size(75, 23);
            this.skeetButton12.TabIndex = 6;
            this.skeetButton12.Text = "Reset";
            this.skeetButton12.Click += new System.EventHandler(this.skeetButton12_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Gray;
            this.label13.Location = new System.Drawing.Point(25, 53);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 12);
            this.label13.TabIndex = 5;
            this.label13.Text = "New: ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Gray;
            this.label15.Location = new System.Drawing.Point(25, 32);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(87, 12);
            this.label15.TabIndex = 4;
            this.label15.Text = "Old / Current: ";
            // 
            // skeetGroupBox2
            // 
            this.skeetGroupBox2.Controls.Add(this.skeetButton2);
            this.skeetGroupBox2.Controls.Add(this.skeetGroupBox3);
            this.skeetGroupBox2.Controls.Add(this.skeetToggle1);
            this.skeetGroupBox2.Font = new System.Drawing.Font("Verdana", 7F);
            this.skeetGroupBox2.Location = new System.Drawing.Point(90, 57);
            this.skeetGroupBox2.Name = "skeetGroupBox2";
            this.skeetGroupBox2.Size = new System.Drawing.Size(267, 265);
            this.skeetGroupBox2.TabIndex = 1;
            this.skeetGroupBox2.TabStop = false;
            this.skeetGroupBox2.Text = "Options";
            // 
            // skeetButton2
            // 
            this.skeetButton2.ColorBottom = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(28)))), ((int)(((byte)(201)))));
            this.skeetButton2.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(28)))), ((int)(((byte)(201)))));
            this.skeetButton2.Font = new System.Drawing.Font("Verdana", 9F);
            this.skeetButton2.Location = new System.Drawing.Point(172, 222);
            this.skeetButton2.Name = "skeetButton2";
            this.skeetButton2.Size = new System.Drawing.Size(87, 31);
            this.skeetButton2.TabIndex = 3;
            this.skeetButton2.Text = "Save";
            this.skeetButton2.Click += new System.EventHandler(this.skeetButton2_Click);
            // 
            // skeetGroupBox3
            // 
            this.skeetGroupBox3.Controls.Add(this.skeetTextBox1);
            this.skeetGroupBox3.Font = new System.Drawing.Font("Verdana", 7F);
            this.skeetGroupBox3.Location = new System.Drawing.Point(23, 53);
            this.skeetGroupBox3.Name = "skeetGroupBox3";
            this.skeetGroupBox3.Size = new System.Drawing.Size(204, 52);
            this.skeetGroupBox3.TabIndex = 2;
            this.skeetGroupBox3.TabStop = false;
            this.skeetGroupBox3.Text = "Path to file";
            // 
            // skeetTextBox1
            // 
            this.skeetTextBox1.BackColor = System.Drawing.Color.Transparent;
            this.skeetTextBox1.ColorBottom = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.skeetTextBox1.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.skeetTextBox1.FocusOnHover = false;
            this.skeetTextBox1.Location = new System.Drawing.Point(6, 18);
            this.skeetTextBox1.MaxLength = 32767;
            this.skeetTextBox1.Multiline = false;
            this.skeetTextBox1.Name = "skeetTextBox1";
            this.skeetTextBox1.ReadOnly = false;
            this.skeetTextBox1.Size = new System.Drawing.Size(192, 23);
            this.skeetTextBox1.TabIndex = 1;
            this.skeetTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.skeetTextBox1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.skeetTextBox1.UseSystemPasswordChar = false;
            // 
            // skeetToggle1
            // 
            this.skeetToggle1.BackColor = System.Drawing.Color.Transparent;
            this.skeetToggle1.Checked = false;
            this.skeetToggle1.ColorBottom = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.skeetToggle1.ColorBottom1 = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(28)))), ((int)(((byte)(201)))));
            this.skeetToggle1.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.skeetToggle1.ColorTop1 = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(28)))), ((int)(((byte)(201)))));
            this.skeetToggle1.Font = new System.Drawing.Font("Verdana", 7F);
            this.skeetToggle1.Location = new System.Drawing.Point(23, 32);
            this.skeetToggle1.Name = "skeetToggle1";
            this.skeetToggle1.Size = new System.Drawing.Size(137, 50);
            this.skeetToggle1.TabIndex = 0;
            this.skeetToggle1.Text = "Write to file";
            this.skeetToggle1.CheckedChanged += new Wagwan_clicker.SkeetToggle.CheckedChangedEventHandler(this.skeetToggle1_CheckedChanged);
            // 
            // skeetBackground1
            // 
            this.skeetBackground1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.skeetBackground1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skeetBackground1.Location = new System.Drawing.Point(0, 0);
            this.skeetBackground1.Name = "skeetBackground1";
            this.skeetBackground1.Size = new System.Drawing.Size(800, 450);
            this.skeetBackground1.TabIndex = 6;
            this.skeetBackground1.Text = "skeetBackground1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.flatTabControl1);
            this.Controls.Add(this.skeetBackground1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.flatTabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.skeetGroupBox1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.skeetGroupBox4.ResumeLayout(false);
            this.skeetGroupBox4.PerformLayout();
            this.skeetGroupBox2.ResumeLayout(false);
            this.skeetGroupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Wagwan_clicker.FlatTabControl flatTabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private Wagwan_clicker.SkeetButton skeetButton1;
        private System.Windows.Forms.TabPage tabPage1;
        private CucklordPRO.SkeetBackground skeetBackground1;
        private Wagwan_clicker.SkeetGroupBox skeetGroupBox1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private Wagwan_clicker.SkeetGroupBox skeetGroupBox4;
        private Wagwan_clicker.SkeetGroupBox skeetGroupBox2;
        private Wagwan_clicker.SkeetButton skeetButton2;
        private Wagwan_clicker.SkeetGroupBox skeetGroupBox3;
        private Wagwan_clicker.SkeetTextBox skeetTextBox1;
        private Wagwan_clicker.SkeetToggle skeetToggle1;
        private Wagwan_clicker.SkeetButton skeetButton12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
    }
}


﻿using System.Drawing;
using Wagwan_clicker;

namespace Wagwan_clicker
{
    public class FlatColors
    {
        public Color Flat = Helpers.FlatColor;
    }
}